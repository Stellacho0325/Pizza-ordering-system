package pizzarOrderSytem;

public enum PizzaSauce {
    tomato,
    barbeque;
}
