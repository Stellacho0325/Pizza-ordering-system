package pizzarOrderSytem;
 
	
		
		
		
		stm.executeUpdate(sql);