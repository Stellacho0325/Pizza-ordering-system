package pizzarOrderSytem;



public class orderitem {

    String customerName;
    Integer customerID;//cId
    Integer productId;
    Integer toppingId;
    Integer orderQuantity;
    double orderPrice;
    

    private customerordering customerOrder;

    public orderitem() {
    }

    public orderitem( Integer productId, Integer orderQuantity,double orderPrice) {
        this.productId = productId;
        this.orderQuantity = orderQuantity;
        this.orderPrice = orderPrice;
    }

    public orderitem( Integer productId, Integer orderQuantity, 
    		double orderPrice, Integer toppingId, customerordering customerOrder) 
    {
        this.productId = productId;
        this.orderQuantity = orderQuantity;
        this.orderPrice = orderPrice;
        this.toppingId = toppingId;
        this.customerOrder = customerOrder;
    }

    public customerordering getCustomerOrder() {
        return customerOrder;
    }

    public void setCustomerOrder(customerordering customerOrder) {
        this.customerOrder = customerOrder;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(Integer orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public double getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        this.orderPrice = orderPrice;
    }

    public Integer getToppingId() {
        return toppingId;
    }

    public void setToppingId(Integer toppingId) {
        this.toppingId = toppingId;
    }
}
