package pizzarOrderSytem;

public enum PizzaSize {
    small,
    medium,
    large
}
