package pizzarOrderSytem;

public class Topping {

    int toppingId;
    String toppingName;
    int productId;

    public Topping() {
    }

    public Topping(String toppingName, int productId) {
        this.toppingId = toppingId;
        this.toppingName = toppingName;
        this.productId = productId;
    }

    public String getToppingName() {
        return toppingName;
    }
    public int getProductId() {
        return productId;
    }
    public void setToppingId(int toppingId) {
        this.toppingId = toppingId;
    }
    public void setToppingName(String toppingName) {
        this.toppingName = toppingName;
    }
  
    public void setProductId(int productId) {
        this.productId = productId;
    }

    @Override
    public String toString() {
        return "Topping{" +
                "toppingId=" + toppingId +
                ", toppingName='" + toppingName + '\'' +
                ", productId=" + productId +
                '}';
    }
}
