package pizzarOrderSytem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.UIManager;
import com.mysql.cj.x.protobuf.MysqlxCrud.Order;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.SwingConstants;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;
import java.sql.*;
import javax.swing.JScrollBar;
import java.awt.Color; 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import pizzarOrderSytem.login;
import pizzarOrderSytem.orderitem;
import pizzarOrderSytem.customerordering;
import pizzarOrderSytem.Topping;

public class pizzamenu {
	private JFrame frame;
	private static JCheckBox chExtraCheese,chSausage,ckMushroom,chBlackOlive,chOnions,chExtraMeat,chCokecokeZero,
	chSprite,chFanta,chBerryJuice,chMangoJuice,chMelonJuice;
	private static JLabel lblLargePrice,lblMediumPrice,lblSmallPrice,lblNewLabel_1_1_1_2,lblNewLabel_1_1_1_3,
	lblNewLabel_1_1_1_4,lblNewLabel_1_1_1_5,lblNewLabel_1_1_1_6,lblQuantity2;
	private static JRadioButton rddineIn,rdTakeaway,rdoSmall,rdoMedium,rdoLarge,rddelivery,rdbtnMushroomPasta,
	rdbtnBolognesePasta,rdbtnClassic,rdoglutenfree,rdoWholewheat,rdbtnTomato,rdbtnBarbeque;
	private static JButton btnBillOut,btnNewButton_1_1,btnNewButton;
	private JTextArea txtOrderdetails;
	private JComboBox cboFlavor;
	private String flavor[] = {"Pepperoni","BBQ Chiken","Hawaiian","Vegeterian","Bacon and Cheese"};
	private double toppingsPrice =0.00;
	private double sidePrice = 0.00;
	private double drinkPrice=0.00;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private double basePrice=0.00;
	private double saucePrice=0.00;
	private int qty=1;
	private JButton btnMakeorder;
	private double subtotal=0.00;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pizzamenu window = new pizzamenu();
					window.frame.setVisible(true);
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yummypizza","root","wh246632!");
					System.out.println("Connected");
					
					Statement stmt=con.createStatement();  
					ResultSet rs=stmt.executeQuery("select * from orders");  
					while(rs.next())  
					System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+"  "+rs.getDouble(3)+" "+rs.getString(0));  
					con.close();  
					}
					catch(Exception e){
						System.out.println(e);
						}  
					}  

		});
	}

	/**
	 * Create the application.
	 */
	public pizzamenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				loadFlavors();
			}
		});
		
		frame.setBounds(100, 100, 922, 920);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Pizza Flavor");
		lblNewLabel.setBounds(16, 6, 125, 16);
		frame.getContentPane().add(lblNewLabel);
		
		cboFlavor = new JComboBox();
		cboFlavor.setBounds(6, 34, 153, 27);
		cboFlavor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showPrice();
			}
		});
		frame.getContentPane().add(cboFlavor);
		
		rdoSmall = new JRadioButton("Small");
		rdoSmall.setBounds(6, 101, 141, 23);
		buttonGroup.add(rdoSmall);
		frame.getContentPane().add(rdoSmall);
		
		rdoMedium = new JRadioButton("Medium");
		rdoMedium.setBounds(6, 129, 141, 23);
		buttonGroup.add(rdoMedium);
		frame.getContentPane().add(rdoMedium);
		
		rdoLarge = new JRadioButton("Large");
		rdoLarge.setBounds(6, 156, 141, 23);
		buttonGroup.add(rdoLarge);
		frame.getContentPane().add(rdoLarge);
		
		chExtraCheese = new JCheckBox("Extra Cheese");
		chExtraCheese.setBounds(19, 369, 159, 23);
		frame.getContentPane().add(chExtraCheese);
		
		chBlackOlive = new JCheckBox("Black Olives ");
		chBlackOlive.setBounds(19, 394, 159, 23);
		frame.getContentPane().add(chBlackOlive);
		
		ckMushroom = new JCheckBox("Mushroom ");
		ckMushroom.setBounds(19, 419, 103, 23);
		frame.getContentPane().add(ckMushroom);
		
		chSausage = new JCheckBox("Sausage");
		chSausage.setBounds(203, 419, 141, 23);
		frame.getContentPane().add(chSausage);
		
		chOnions = new JCheckBox("Onions ");
		chOnions.setBounds(203, 394, 141, 23);
		frame.getContentPane().add(chOnions);
		
		chExtraMeat = new JCheckBox("Extra Meat");
		chExtraMeat.setBounds(203, 369, 141, 23);
		frame.getContentPane().add(chExtraMeat);
		
		JLabel lblNewLabel_3 = new JLabel("Choose:");
		lblNewLabel_3.setBounds(26, 488, 125, 16);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel sad = new JLabel("Size and Price:");
		sad.setBounds(16, 73, 125, 16);
		frame.getContentPane().add(sad);
		
		JLabel lblNewLabel_3_2 = new JLabel("Toppings:");
		lblNewLabel_3_2.setBounds(16, 335, 125, 16);
		frame.getContentPane().add(lblNewLabel_3_2);
		
		rddineIn = new JRadioButton("Dine In");
		rddineIn.setBounds(16, 516, 141, 23);
		buttonGroup_1.add(rddineIn);
		frame.getContentPane().add(rddineIn);
		
		rdTakeaway = new JRadioButton("Take Away");
		rdTakeaway.setBounds(16, 544, 141, 23);
		buttonGroup_1.add(rdTakeaway);
		frame.getContentPane().add(rdTakeaway);
		
		rddelivery = new JRadioButton("Delivery");
		rddelivery.setBounds(16, 571, 141, 23);
		buttonGroup_1.add(rddelivery);
		frame.getContentPane().add(rddelivery);
		
		JButton btnorderAgain = new JButton("Order Again");
		btnorderAgain.setBounds(61, 762, 117, 29);
		btnorderAgain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				orderAgain();}
					
				});
		frame.getContentPane().add(btnorderAgain);
		
		btnMakeorder = new JButton("Make Order");
		btnMakeorder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
		String insertSql = "INSERT INTO orders (orderId,cId,date,subtotal" 
		+"VALUES(null,null, "+subtotal+");";
			}

		});
		
		btnMakeorder.setBounds(71, 803, 117, 29);
		frame.getContentPane().add(btnMakeorder);
		
		JLabel lbQuantity = new JLabel("Quantity");
		lbQuantity.setBounds(16, 620, 125, 16);
		frame.getContentPane().add(lbQuantity);
		
		btnNewButton = new JButton("-");
		btnNewButton.setBounds(36, 658, 66, 29);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				qty--;
				lblQuantity2.setText(String.valueOf(qty));
			}
		});
		btnNewButton.setBackground(Color.PINK);
		btnNewButton.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		frame.getContentPane().add(btnNewButton);
		
		
		btnNewButton_1_1 = new JButton("+");
		btnNewButton_1_1.setBounds(135, 658, 66, 29);
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				qty++;
				lblQuantity2.setText(String.valueOf(qty));
			}
		});
		btnNewButton_1_1.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		frame.getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("Order Details:");
		lblNewLabel_2.setBounds(390, 335, 117, 16);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Side:");
		lblNewLabel_3_1_1.setBounds(390, 73, 125, 16);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		rdbtnMushroomPasta = new JRadioButton("Cream Mushroom Pasta");
		rdbtnMushroomPasta.setBounds(386, 101, 237, 23);
		rdbtnMushroomPasta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		frame.getContentPane().add(rdbtnMushroomPasta);
		
		rdbtnBolognesePasta = new JRadioButton("Bolognese Pasta ");
		rdbtnBolognesePasta.setBounds(386, 129, 222, 23);
		frame.getContentPane().add(rdbtnBolognesePasta);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("Drinks:");
		lblNewLabel_3_2_1.setBounds(388, 188, 125, 16);
		frame.getContentPane().add(lblNewLabel_3_2_1);
		
		chCokecokeZero = new JCheckBox("Coke/Coke Zero");
		chCokecokeZero.setBounds(382, 222, 170, 23);
		frame.getContentPane().add(chCokecokeZero);
		
		chSprite = new JCheckBox("Sprite");
		chSprite.setBounds(382, 247, 128, 23);
		frame.getContentPane().add(chSprite);
		
		chFanta = new JCheckBox("Fanta");
		chFanta.setBounds(382, 272, 128, 23);
		frame.getContentPane().add(chFanta);
		
		chBerryJuice = new JCheckBox("Berry Juice");
		chBerryJuice.setBounds(599, 222, 128, 23);
		frame.getContentPane().add(chBerryJuice);
		
		chMangoJuice = new JCheckBox("Mango Juice");
		chMangoJuice.setBounds(599, 247, 128, 23);
		frame.getContentPane().add(chMangoJuice);
		
		chMelonJuice = new JCheckBox("Melon Juice");
		chMelonJuice.setBounds(599, 272, 128, 23);
		frame.getContentPane().add(chMelonJuice);
		
		lblSmallPrice = new JLabel("");
		lblSmallPrice.setBounds(166, 105, 82, 16);
		lblSmallPrice.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblSmallPrice);
		
		lblMediumPrice = new JLabel("");
		lblMediumPrice.setBounds(166, 133, 82, 16);
		lblMediumPrice.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblMediumPrice);
		
		lblLargePrice = new JLabel("");
		lblLargePrice.setBounds(166, 160, 82, 16);
		lblLargePrice.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblLargePrice);
		
		btnBillOut = new JButton("Bill out");
		btnBillOut.setBounds(61, 713, 117, 29);
		btnBillOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				showOrderDetails();}
			});
		
		frame.getContentPane().add(btnBillOut);
		
		txtOrderdetails = new JTextArea();
		txtOrderdetails.setBounds(392, 369, 432, 517);
		frame.getContentPane().add(txtOrderdetails);
		
		JLabel lblBase = new JLabel("Base:");
		lblBase.setBounds(189, 188, 125, 16);
		frame.getContentPane().add(lblBase);
		
		rdbtnClassic = new JRadioButton("Classic");
		rdbtnClassic.setBounds(189, 216, 141, 23);
		frame.getContentPane().add(rdbtnClassic);
		
		rdoWholewheat = new JRadioButton("Whole Wheat");
		rdoWholewheat.setBounds(189, 244, 141, 23);
		frame.getContentPane().add(rdoWholewheat);
		
		rdoglutenfree = new JRadioButton("Gluten free");
		rdoglutenfree.setBounds(189, 275, 141, 23);
		frame.getContentPane().add(rdoglutenfree);
		
		JLabel lblSauce = new JLabel("Sauce:");
		lblSauce.setBounds(16, 191, 125, 16);
		frame.getContentPane().add(lblSauce);
		
		rdbtnTomato = new JRadioButton("Tomato");
		rdbtnTomato.setBounds(16, 216, 141, 23);
		frame.getContentPane().add(rdbtnTomato);
		
		rdbtnBarbeque = new JRadioButton("Barbeque");
		rdbtnBarbeque.setBounds(16, 244, 141, 23);
		frame.getContentPane().add(rdbtnBarbeque);
		
		JLabel lblNewLabel_1 = new JLabel("$3.0");
		lblNewLabel_1.setBounds(527, 226, 61, 16);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("$3.0");
		lblNewLabel_1_1.setBounds(526, 251, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("$3.0");
		lblNewLabel_1_1_1.setBounds(526, 276, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("$4.0");
		lblNewLabel_1_2.setBounds(719, 226, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("$4.0");
		lblNewLabel_1_2_1.setBounds(719, 251, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_2_2 = new JLabel("$4.0");
		lblNewLabel_1_2_2.setBounds(719, 276, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_2_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("$5.0");
		lblNewLabel_1_3.setBounds(576, 105, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("$5.0");
		lblNewLabel_1_3_1.setBounds(576, 133, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_3_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("$1.0");
		lblNewLabel_1_1_1_1.setBounds(140, 373, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_1_1_1);
		
		lblNewLabel_1_1_1_2 = new JLabel("$2.0");
		lblNewLabel_1_1_1_2.setBounds(140, 398, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_1_1_2);
		
		lblNewLabel_1_1_1_3 = new JLabel("$1.0");
		lblNewLabel_1_1_1_3.setBounds(140, 423, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_1_1_3);
		
		lblNewLabel_1_1_1_4 = new JLabel("$2.0");
		lblNewLabel_1_1_1_4.setBounds(313, 373, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_1_1_4);
		
		lblNewLabel_1_1_1_5 = new JLabel("$1.0");
		lblNewLabel_1_1_1_5.setBounds(313, 398, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_1_1_5);
		
		lblNewLabel_1_1_1_6 = new JLabel("$2.0");
		lblNewLabel_1_1_1_6.setBounds(313, 423, 61, 16);
		frame.getContentPane().add(lblNewLabel_1_1_1_6);
		
		lblQuantity2 = new JLabel("1");
		lblQuantity2.setBounds(114, 663, 61, 16);
		frame.getContentPane().add(lblQuantity2);}
		
		
		private void loadFlavors() {
			for(String flavors: flavor) {
				cboFlavor.addItem(flavors);
			}
		}
		private void showPrice() {
			if (cboFlavor.getSelectedIndex()==0)
			{
				lblSmallPrice.setText("10.0");
				lblMediumPrice.setText("12.0");
				lblLargePrice.setText("14.0");	
			}
			else if(cboFlavor.getSelectedIndex()==1)
			{
				lblSmallPrice.setText("13.0");
				lblMediumPrice.setText("15.0");
				lblLargePrice.setText("17.0");
			}
				
			else if(cboFlavor.getSelectedIndex()==2)
			{	
				lblSmallPrice.setText("9.0");
				lblMediumPrice.setText("11.0");
				lblLargePrice.setText("13.0");
			}
			else if(cboFlavor.getSelectedIndex()==3)
			{	
				lblSmallPrice.setText("11.0");
				lblMediumPrice.setText("13.0");
				lblLargePrice.setText("15.0");
			}
			else
			{	
				lblSmallPrice.setText("11.0");
				lblMediumPrice.setText("13.0");
				lblLargePrice.setText("15.0");
			}
		}
		private String toppingPrice() {
			String toppings ="";
			if(chExtraCheese.isSelected())
			{
				toppingsPrice += 1.0;
				toppings = toppings+"\n\t"+chExtraCheese.getText()+"\t\t"+"1.00";
				
			}
			if(chSausage.isSelected())
			{
				toppingsPrice += 2.0;
				toppings = toppings +"\n\t"+chSausage.getText()+"\t\t"+"2.00";
			}
			if(ckMushroom.isSelected())
			{
				toppingsPrice += 1.0;
				toppings = toppings +"\n\t"+ckMushroom.getText()+"\t\t"+"1.00";
				
			}
			if(chBlackOlive.isSelected())
			{
				toppingsPrice += 2.0;
				toppings = toppings +"\n\t"+chBlackOlive.getText()+"\t\t"+"2.00";
				
			}
			if(chOnions.isSelected())
			{
				toppingsPrice += 1.0;
				toppings = toppings +"\n\t"+chOnions.getText()+"\t\t"+"1.00";
				
			}
			if(chExtraMeat.isSelected())
			{
				toppingsPrice += 2.0;
				toppings = toppings +"\n\t"+chExtraMeat.getText()+"\t\t"+"2.00";
				
			}
			return toppings;
		}
		private String sidePrice() {
			String side ="";
			if(rdbtnMushroomPasta.isSelected())
			{
				sidePrice += 5.0;
				side = side+"\n"+rdbtnMushroomPasta.getText()+"\t\t"+"5.00";
			}
			if(rdbtnBolognesePasta.isSelected())
			{
				sidePrice += 5.0;
				side = side +"\n"+rdbtnBolognesePasta.getText()+"\t\t"+"5.00";
			}	
			return side;
		}
		
		private String pizzaBase() {
			String base ="";
			if(rdbtnClassic.isSelected())
			{
			
				base = base +rdbtnClassic.getText()+"\t\t";
				
			}
			else if(rdoWholewheat.isSelected())
			{
			
				base = base +rdoWholewheat.getText()+"\t\t";
			}	
			else if(rdoglutenfree.isSelected())
			{
				
				base = base +rdoglutenfree.getText()+"\t\t";
			}	
			else
			{
				
				base = "\t\t Default Base Selected";
			}
			return base;
		}
		private String pizzaSauce() {
			String sauce ="";
			if(rdbtnTomato.isSelected())
			{
				sauce = sauce +rdbtnTomato.getText()+"\t\t";
				
			}
			else if(rdbtnBarbeque.isSelected())
			{
				sauce = sauce +rdbtnBarbeque.getText()+"\t\t";
			}	
			else {
				sauce="\n Default Sauce Selected\n";
			}
			return sauce;
		}
		
			private String drinkPrice() {
				String drink ="";
				if(chCokecokeZero.isSelected())
				{
					drinkPrice += 3.0;
				drink= drink+"\n"+chCokecokeZero.getText()+"\t\t"+"3.00";
					
			}
				if(chSprite.isSelected())
				{
					drinkPrice += 3.0;
					drink = drink+"\n"+chSprite.getText()+"\t\t"+"3.00";
					
			}
				if(chFanta.isSelected())
				{
					drinkPrice += 3.0;
					drink = drink+"\n"+chFanta.getText()+"\t\t"+"3.00";
					
			}
				if(chBerryJuice.isSelected())
				{
					drinkPrice += 4.0;
					drink = drink+"\n"+chBerryJuice.getText()+"\t\t"+"4.00";
					
			}
				if(chMangoJuice.isSelected())
				{ 
					drinkPrice += 4.0;
					drink = drink+"\n"+chMangoJuice.getText()+"\t\t"+"4.00";
					
			}
				if(chMelonJuice.isSelected())
				{
					drinkPrice += 4.0;
					drink = drink+"\n"+chMelonJuice.getText()+"\t\t"+"4.00";
					
			}
				return drink;
		}
		private String sizeOfPizza() {
			String size="";
			if(rdoSmall.isSelected())
				size=rdoSmall.getText();
			else if(rdoMedium.isSelected())
				size=rdoMedium.getText();
			else
				size=rdoLarge.getText();
			
			return size;
				
		}
		private double priceOfPizza() {
			double pizzaPrice=0;
			if(rdoSmall.isSelected())
				pizzaPrice=Double.parseDouble(lblSmallPrice.getText());
		
			else if(rdoMedium.isSelected())
				pizzaPrice=Double.parseDouble(lblMediumPrice.getText());
				
			else
				pizzaPrice=Double.parseDouble(lblLargePrice.getText());
			return pizzaPrice;
		}
		
		private String serviceMethod() {
			String service="";
			if(rddineIn.isSelected())
				service="DINE IN";
			else if(rdTakeaway.isSelected())
				service="Take Away";
			else
				service="Delivery";
			return service;
		}
		
		private double serviceFee() {
			double serviceFee =0;
			if(rddelivery.isSelected())
				serviceFee=5.00;
			else
				serviceFee=0.00;
			
			return serviceFee;}
		
			private void orderAgain(){
				txtOrderdetails.setText(null);
			}
			
		private void showOrderDetails() {
			
			int quantity=Integer.parseInt(lblQuantity2.getText());
			double subtotal=toppingsPrice+priceOfPizza()*quantity+serviceFee()+sidePrice+drinkPrice;
			
			txtOrderdetails.setText("Flavor:\t"+cboFlavor.getSelectedItem()+"\n\nSize:\t" +sizeOfPizza()+"\n\nPrice:\t" +priceOfPizza()+"\n\nBase:\t"
					+pizzaBase()+"\n\nSauce:\t"+pizzaSauce()+"\n\nToppings:\t"+toppingPrice()+"\n\nSide:\t"+sidePrice()+
					"\n\nDrinks:\t"+drinkPrice()+"\n\nService:\t"+serviceMethod()+"\n\nQuantity:\t"+"x"+ quantity+ 
					"\n\n**********************************************"
					+"\n\nSubTotal Price\t"+(subtotal=toppingsPrice+priceOfPizza()*quantity+serviceFee()+sidePrice+drinkPrice));
					
			
		
				
}
		
		}
		
		
		
			
		
			

  
 

