package pizzarOrderSytem;

public enum ProductType {
    pizza,
    side,
    drink
}
