package pizzarOrderSytem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class login {
private static JLabel ctotLabel, totLabel, orLabel, chLabel, seeLabel, tyLabel, disLabel, cpaidLabel, methodLabel, amountLabel, expLabel, cardLabel, quesLabel, custLabel, firstLabel, passLabel, lastLabel, success, subLabel, addLabel, staLabel, postLabel, phLabel, emLabel, ccnumLabel, ccexpLabel, balLabel, welcomeLabel, userLabel;
private static JTextField disText, cpaidText, expText, cardText, custText, firstText, lastText, addText, subText, staText, postText, phText, emText, ccnumText, ccexpText, balText;
private static JPasswordField passwordText;
private static JButton IstButton, onlButton, cpayButton, cashButton, cardButton, payButton, orderButton, bookButton, loginButton, noButton, regButton, yesButton;

public static void main (String[] args) {
	
	login.Login();
	
}

public static void Login() {

	
	JPanel panel = new JPanel();
	JFrame frame = new JFrame();
	frame.setSize(400, 200);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	frame.add(panel);
	frame.setTitle("Login");
	panel.setLayout(null);
	
	custLabel = new JLabel("Customer number:");
	custLabel.setBounds(10, 20, 160, 25);
	panel.add(custLabel);
	
	custText = new JTextField(20);
	custText.setBounds(150, 20, 165, 25);
	panel.add(custText);
	
	passLabel = new JLabel("Password:");
	passLabel.setBounds(10, 60, 160, 25);
	panel.add(passLabel);
	
	passwordText = new JPasswordField();
	passwordText.setBounds(150, 60, 165, 25);
	panel.add(passwordText);
	
	
	
	loginButton = new JButton("Login");
	loginButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/yummypizza","root","wh246632!")){
				System.out.println("Database connected");
				
				String cId = custText.getText();
				String password = passwordText.getText();
				
				Statement stm = connection.createStatement();
				
				String sql = "Select * from login where cId='" + cId +"' and password='"+password+"'";
				ResultSet rs = stm.executeQuery(sql);
				
				if(rs.next()) 
					pizzamenu.main(null);
					
				else
					success.setText("Login failed, please try again.");
				} catch (SQLException e1) {
					e1.printStackTrace();;
	
				}	}});
	loginButton.setBounds(150, 120, 80, 25);
	panel.add(loginButton);
	
	frame.setVisible(true);

}}
