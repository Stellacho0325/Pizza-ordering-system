import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;

String timeStamp = new SimpleDateFormat("yyyy.MM.dd").format(new java.util.Date());

					
						String orderId= orderId.getText();
						String cId = cId.getText();
						String date = date.getText();
						Double subtotal = subtotal.getText();
					
						String sql = "select * from orders where orderId='"+orderId+"'";
						System.out.println(sql);	
							
				}
						String insertSql = "INSERT INTO orders (orderId,cId,date,subtotal" 
				+VALUES(null,null, '"+jl+"', "+subtotal+");";
						
					payment.insertSql=insertSql;
					payment.main(null);
					
					
					
					public void actionPerformed(ActionEvent e){
						
						String orderId= orderId.getText();
						String cId = customerId.getText();
						String date = date.getText();
						Double subtotal = subtotal.getText();
					
						String sql = "select * from orders where orderId='"+orderId+"'";
						System.out.println(sql);	
							
				}
						String insertSql = "INSERT INTO Bookings (bookingId,bookingDate," +
								"bookingTime,numberOFPerson,cid,customerName," +
								"Discount)VALUES(null,'"+cId+"', '"+date+"', "+subtotal+");";
						
					}
				);		
				}