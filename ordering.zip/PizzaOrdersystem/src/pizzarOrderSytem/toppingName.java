package pizzarOrderSytem;

public enum toppingName {

	ExtraCheese,
	BlackOlive,
	Mushroom,
	Onions,
	Sausage,
	ExtraMeat
}
