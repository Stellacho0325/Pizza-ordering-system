package pizzarOrderSytem;

public enum PizzaBase {
    classic,
    wholemeal,
    glutenFree
}
